import React from 'react'

export default function RightPart(){
  return(
    <div className="RightPart">
      헬로우
    </div>
  )
}