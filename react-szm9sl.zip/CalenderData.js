import { ExportList } from './src/App';

function CalenderData() {
  const date = new Date();
  const worker = ExportList;
  //년도, 월, 일 변수
  const year = date.getFullYear();
  const month = date.getMonth() + 1;

  //월의 첫번째 요일 구하기
  const firstDate = new Date(year, date.getMonth(), 1);
  const firstDay = firstDate.getDay();

  //월의 마지막 일 구하기
  const lastDate = new Date(year, month, 0);
  const lastDateDay = lastDate.getDate();

  //달력의 주 수(행의 값) 구하기
  const calenderWeekCount = Math.ceil((firstDay + lastDateDay) / 7);
  let calenderDay = 0;
  let calenderPos = 0;

  const resultMonth = [];
  for (let row = 0; row < calenderWeekCount; row++) {
    const dayList = [];
    for (let col = 0; col < 7; col++) {
      if (firstDay <= calenderPos) {
        calenderDay++;
        const today = new Date(
          date.getFullYear(),
          date.getMonth(),
          calenderDay
        );
        if (calenderDay > 31) {
          dayList.push({
            date: 0,
            day: col,
            worker: ' ',
          });
        } else {
          dayList.push({
            date: calenderDay,
            day: today.getDay(),
            worker: ' ',
          });
        }
      } else {
        dayList.push({
          date: 0,
          day: col,
          worker: ' ',
        });
      }
      calenderPos++;
    }
    resultMonth.push(dayList);
  }
  return resultMonth;
}

const resultMonth = CalenderData();

export default resultMonth;
