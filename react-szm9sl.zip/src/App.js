import React, { useState } from 'react';
import './style.css';
import LeftPart from './Components/LeftPart';
import RightPart from './Components/RightPart';
import { DataContext } from './Context/DataContext';
import resultMonth from '../CalenderData';

function App() {
  const [data, setData] = useState({
    worker: [],
    calenderDate: resultMonth,
  });
  const [num, setNum] = useState(0);
  const workerList = data.worker.map((a) => a.name);
  console.log('workerList', workerList);

  var List = data.worker;

  return (
    <div className="Container">
      <DataContext.Provider value={{ data, setData }}>
        <LeftPart />
        <RightPart />
      </DataContext.Provider>
    </div>
  );
}

export default App;

// resultMonth 데이터 형식
// [{
//   date: 0, <- 일자 들어가있음 빈칸일 경우 0 넣음
//   day: col, <- 요일 위치
//   worker: " " <- 근무자 넣을 속성, 나중에 수정해줄 것임
// } X7]
//
//
