import React from 'react';
import useUuid from '../hooks/useUuid';

export default function DayOfTheWeek() {
  const week = ['일', '월', '화', '수', '목', '금', '토'];
  const result = week.map((day) => <th key={useUuid()}>{day}</th>);

  return <thead>{result}</thead>;
}
