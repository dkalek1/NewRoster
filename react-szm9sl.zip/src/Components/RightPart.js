import React from 'react';
import DayOfTheWeek from './DayOfTheWeek';
import MonthDate from './MonthDate';
import Header from './Header';

export default function RightPart() {
  return (
    <div className="RightPart">
      <Header />
      <table>
        <DayOfTheWeek />
        <MonthDate />
      </table>
    </div>
  );
}
