import React, { Fragment } from 'react';
import useUuid from '../hooks/useUuid';

export default function WeekMaker({ week, worker }) {
  const result = week.map((day) => (
    <td key={useUuid()}>
      {Boolean(day.date) ? day.date : ' '}
      <p>{day.date ? worker : ' '}</p>
    </td>
  ));

  return <Fragment>{result}</Fragment>;
}
