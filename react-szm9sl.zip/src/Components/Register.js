import React, { useContext, Fragment, useRef, useState } from 'react';
import { DataContext } from '../Context/DataContext';
import useUuid from '../hooks/useUuid';

export default function Register() {
  const { data, setData } = useContext(DataContext);
  const [input, setInput] = useState('');
  const focus = useRef();

  const onChange = (e) => {
    setInput(e.target.value);
  };

  const onCreate = () => {
    setData({
      ...data,
      worker: data.worker.concat({ name: input, id: useUuid() }),
    });
    setInput('');
    focus.current.value = '';
    focus.current.focus();
  };

  return (
    <Fragment>
      <input
        type="text"
        placeholder="관등성명까지 입력해주세요"
        onChange={onChange}
        ref={focus}
      />
      <button onClick={onCreate}>입력</button>
    </Fragment>
  );
}
